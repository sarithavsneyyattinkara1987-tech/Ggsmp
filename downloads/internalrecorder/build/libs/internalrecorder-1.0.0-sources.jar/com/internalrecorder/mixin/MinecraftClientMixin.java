package com.internalrecorder.mixin;

import com.internalrecorder.capture.RecordingManager;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public abstract class MinecraftClientMixin {
    @Inject(
        method = "render",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/util/Window;swapBuffers(Lnet/minecraft/client/util/tracy/TracyFrameCapturer;)V"
        )
    )
    private void internalrecorder$captureAfterHud(boolean tick, CallbackInfo callbackInfo) {
        RecordingManager.captureFrame((class_310) (Object) this);
    }
}