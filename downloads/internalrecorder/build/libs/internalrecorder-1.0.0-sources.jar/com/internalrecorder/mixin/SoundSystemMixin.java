package com.internalrecorder.mixin;

import com.internalrecorder.audio.AudioCaptureBridge;
import net.minecraft.class_1113;
import net.minecraft.class_1140;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1140.class)
public abstract class SoundSystemMixin {
    @Inject(
        method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;",
        at = @At("HEAD")
    )
    private void internalrecorder$observeSoundStart(
        class_1113 sound,
        CallbackInfoReturnable<class_1140.class_11518> callbackInfo
    ) {
        AudioCaptureBridge.onSoundStarted(sound);
    }
}