package com.internalrecorder.mixin;

import com.internalrecorder.client.RecordingScreen;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_4185;
import net.minecraft.class_433;
import net.minecraft.class_6379;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_433.class)
public abstract class GameMenuScreenMixin {
    @Shadow
    protected int width;

    @Shadow
    protected int height;

    @Shadow
    protected abstract <T extends class_364 & class_4068 & class_6379> T addDrawableChild(T drawable);

    @Inject(method = "init", at = @At("TAIL"))
    private void internalrecorder$addCameraButton(CallbackInfo callbackInfo) {
        class_433 menu = (class_433) (Object) this;
        class_310 client = class_310.method_1551();
        addDrawableChild(
            class_4185.method_46430(class_2561.method_43470("CAM"), button -> client.method_1507(new RecordingScreen(menu)))
            .method_46434(width - 110, height - 28, 100, 20)
                .method_46431()
        );
    }
}
