package com.internalrecorder.client;

import com.internalrecorder.capture.RecordingManager;
import java.util.Locale;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public final class RecordingHud {
    private RecordingHud() {
    }

    public static void render(class_332 drawContext, class_9779 tickCounter) {
        if (!RecordingManager.isRecording()) {
            return;
        }
        long totalSeconds = RecordingManager.elapsedMillis() / 1000L;
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        String timer = String.format(Locale.ROOT, "%02d:%02d", minutes, seconds);
        drawContext.method_27535(
            net.minecraft.class_310.method_1551().field_1772,
            class_2561.method_43470(RecordingManager.isPaused() ? "PAUSED " + timer : "REC " + timer),
            8,
            8,
            RecordingManager.isPaused() ? 0xFFFFCC33 : 0xFFFF3333
        );
    }
}