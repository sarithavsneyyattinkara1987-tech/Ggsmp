package com.internalrecorder.client;

import com.internalrecorder.capture.RecordingManager;
import com.internalrecorder.config.RecorderConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class RecordingScreen extends class_437 {
    private final class_437 parent;
    private class_4185 startButton;
    private class_4185 stopButton;
    private class_4185 pauseButton;
    private class_4185 fpsButton;
    private class_4185 crfButton;

    public RecordingScreen(class_437 parent) {
        super(class_2561.method_43470("InternalRecorder"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int centerX = field_22789 / 2;
        int top = field_22790 / 2 - 72;
        startButton = method_37063(class_4185.method_46430(class_2561.method_43470("Start recording"), button -> {
            RecordingManager.start(field_22787);
            refreshButtons();
        }).method_46434(centerX - 155, top, 150, 20).method_46431());
        stopButton = method_37063(class_4185.method_46430(class_2561.method_43470("Stop recording"), button -> {
            RecordingManager.stop(field_22787, "Recording saved.");
            refreshButtons();
        }).method_46434(centerX + 5, top, 150, 20).method_46431());
        pauseButton = method_37063(class_4185.method_46430(class_2561.method_43470("Pause recording"), button -> {
            RecordingManager.togglePause(field_22787);
            refreshButtons();
        }).method_46434(centerX - 155, top + 28, 310, 20).method_46431());
        fpsButton = method_37063(class_4185.method_46430(class_2561.method_43470(""), button -> cycleFps()).method_46434(centerX - 155, top + 68, 150, 20).method_46431());
        crfButton = method_37063(class_4185.method_46430(class_2561.method_43470(""), button -> cycleCrf()).method_46434(centerX + 5, top + 68, 150, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> method_25419()).method_46434(centerX - 60, field_22790 - 32, 120, 20).method_46431());
        refreshButtons();
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        method_25420(drawContext, mouseX, mouseY, delta);
        drawContext.method_27534(field_22793, field_22785, field_22789 / 2, field_22790 / 2 - 112, 0xFFFFFFFF);
        RecorderConfig config = RecordingManager.config();
        drawContext.method_27534(field_22793, class_2561.method_43470("Resolution: " + config.outputWidth + " x " + config.outputHeight), field_22789 / 2, field_22790 / 2 + 22, 0xFFB8C2D0);
        drawContext.method_27534(field_22793, class_2561.method_43470("Output: " + config.outputDirectory), field_22789 / 2, field_22790 / 2 + 38, 0xFFB8C2D0);
        drawContext.method_27534(field_22793, class_2561.method_43470("FFmpeg: " + config.ffmpegPath), field_22789 / 2, field_22790 / 2 + 54, 0xFFB8C2D0);
        refreshButtons();
        super.method_25394(drawContext, mouseX, mouseY, delta);
    }

    private void refreshButtons() {
        if (startButton == null) {
            return;
        }
        boolean recording = RecordingManager.isRecording();
        startButton.field_22763 = !recording;
        stopButton.field_22763 = recording;
        pauseButton.field_22763 = recording;
        pauseButton.method_25355(class_2561.method_43470(RecordingManager.isPaused() ? "Resume recording" : "Pause recording"));
        RecorderConfig config = RecordingManager.config();
        fpsButton.field_22763 = !recording;
        crfButton.field_22763 = !recording;
        fpsButton.method_25355(class_2561.method_43470("FPS: " + config.fps));
        crfButton.method_25355(class_2561.method_43470("CRF: " + config.crf));
    }

    private void cycleFps() {
        RecorderConfig config = RecordingManager.config();
        config.fps = config.fps < 30 ? 30 : config.fps < 60 ? 60 : config.fps < 120 ? 120 : 30;
        config.save();
        refreshButtons();
    }

    private void cycleCrf() {
        RecorderConfig config = RecordingManager.config();
        config.crf = config.crf >= 51 ? 0 : Math.min(51, config.crf + 4);
        config.save();
        refreshButtons();
    }
}
